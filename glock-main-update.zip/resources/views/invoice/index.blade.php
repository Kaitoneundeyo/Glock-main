@extends('layouts.app')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>INVOICE</h1>
        </div>
        <div>
            @livewire('stokmasuk-component')
        </div>
    </section>
@endsection
