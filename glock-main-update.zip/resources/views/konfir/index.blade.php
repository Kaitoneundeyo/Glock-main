@extends('layouts.app')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>KONFIRMASI PEMBAYARAN</h1>
        </div>
        
    </section>
@endsection
