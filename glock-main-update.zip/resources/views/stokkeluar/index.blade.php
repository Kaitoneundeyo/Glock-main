@extends('layouts.app')

@section('content')
    <section class="section">
        <div class="section-header">
            <h1>STOK KELUAR</h1>
        </div>
        <div>
            @livewire('stok-keluar-component')
        </div>

@endsection
